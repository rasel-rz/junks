﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Inter_molecular_ineffective_CRO
    {
        Population pop = new Population();
        Repair rep = new Repair();
        List<int[]> m_new = new List<int[]>();

        private List<int[]> M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }
        //multiple
        public List<int[]> inter_molecular_ineffective(int[] m1, int[] m2)
        {
            int x1, x2;
            int[] m11 = new int[m1.Length];
            int[] m22 = new int[m2.Length];
            Random rand = new Random();
            x1 = (m1.Length/3)-1;
           
            x2 = x1+(m1.Length/3);
            for (int i = 0; i < m1.Length; i++ )
            {
                if (i<=x1 || i>x2)
                {
                        m11[i] = m1[i];
                        m22[i] = m2[i];
                }
                else
                {
                    m11[i] = m2[i];
                    m22[i] = m1[i];
                }
            }
            m11 = rep.repair_operator(m11);
            m22 = rep.repair_operator(m22);
            m_new.Add(m11);
            m_new.Add(m22);

                return m_new;
        }
    }
}
