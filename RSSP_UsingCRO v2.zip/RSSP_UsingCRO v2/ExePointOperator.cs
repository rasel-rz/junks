﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class ExePointOperator
    {
        Repair rep = new Repair();
        List<int[]> m_new = new List<int[]>();

        public List<int[]> exePointOp(int[] m1, int[] m2)
        {
            int divPoint = (m1.Length / 3);
            int[] m11 = new int[divPoint];
            int[] m12 = new int[divPoint];
            int[] m13 = new int[m1.Length - (2 * divPoint)];
            int[] m21 = new int[divPoint];
            int[] m22 = new int[divPoint];
            int[] m23 = new int[m2.Length- (2 * divPoint)];
            //Random rand = new Random();

            Array.Copy(m1, 0, m11, 0, divPoint);
            Array.Copy(m2, 0, m21, 0, divPoint);
            Array.Copy(m1, divPoint, m12, 0, divPoint);
            Array.Copy(m2, divPoint, m22, 0, divPoint);
            Array.Copy(m1, divPoint*2, m13, 0, (m1.Length - (2 * divPoint)));
            Array.Copy(m2, divPoint*2, m23, 0, (m2.Length - (2 * divPoint)));

            m11 = rep.repair_operator(m11);
            m12 = rep.repair_operator(m12);
            m13 = rep.repair_operator(m13);
            m21 = rep.repair_operator(m21);
            m22 = rep.repair_operator(m22);
            m23 = rep.repair_operator(m23);
            
            m_new.Add(m11);
            m_new.Add(m12);
            m_new.Add(m13);
            m_new.Add(m21);
            m_new.Add(m22);
            m_new.Add(m23);

            return m_new;
        }
    }
}
