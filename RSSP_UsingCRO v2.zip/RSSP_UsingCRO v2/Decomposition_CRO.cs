﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Decomposition_CRO
    {
        Population pop = new Population();
        Repair rep = new Repair();
        List<int[]> m_new = new List<int[]>();

        private List<int[]> M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }
        //single point operator
        public List<int[]> decomposition(int[] m11, int [] m22)
        {
            //Random rand = new Random();
            int[] m1 = new int[m11.Length];
            int[] m2 = new int[m11.Length];
            Random rand = new Random();
            int x1 = rand.Next(0, m1.Length);

            for (int i = 0; i < x1; i++ )
            {
                m1[i] = m11[i];
            }
            for (int i = x1; i < m11.Length; i++ )
            {
                m2[i] = m11[i];
            }
            for (int i = x1; i < m22.Length; i++ )
            {
                /* for (int i1 = 0; i1 < 4000; i1++)
                 {
                     for (int i2 = 0; i2 < 2000; i2++)
                     {

                     }
                 }*/

                //m1[i] = rand.Next(0, m11.Length);
                m1[i] = m22[i];
            }
            for (int i = x1; i < m11.Length; i++)
            {
                /* for (int i1 = 0; i1 < 4000; i1++)
                 {
                     for (int i2 = 0; i2 < 2000; i2++)
                     {

                     }
                 }*/

                //m1[i] = rand.Next(0, m11.Length);
                m2[i] = m11[i];
            }
            /*for (int i = 0; i < mid; i++)
            {
                for (int i1 = 0; i1 < 4000; i1++)
                {
                    for (int i2 = 0; i2 < 2000; i2++)
                    {

                    }
                }

                m2[i] = rand.Next(0, m11.Length);
            }*/
            m1 = rep.repair_operator(m1);
            m2 = rep.repair_operator(m2);
            m_new.Add(m1);
            m_new.Add(m2);

            return m_new;
        }
    }
}
