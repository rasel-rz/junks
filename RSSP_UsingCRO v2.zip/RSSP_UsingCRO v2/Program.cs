﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Program
    {
        static void Main(string[] args)
        {
            SinglePointOperator spo = new SinglePointOperator();
            UniformOperator ufo = new UniformOperator();
            MultiPointOperator mpo = new MultiPointOperator();
            ExePointOperator epo = new ExePointOperator();

            int[] stem1 = { 1, 3, 4, 7, 2, 5, 6 };
            int[] stem2 = { 3, 4, 7, 1, 2, 5, 6 };

            List<int[]> temp = spo.singlePointOp(stem1, stem2);
            Console.WriteLine(string.Join(", ", temp[1]));

            int[] temp_0 = ufo.uniformOp(stem1, stem2);
            Console.WriteLine(string.Join(", ", temp_0));

            List<int[]> temp_1 = mpo.multiPointOp(stem1, stem2);
            Console.WriteLine(string.Join(", ", temp_1[1]));

            List<int[]> temp_2 = epo.exePointOp(stem1, stem2);
            Console.WriteLine(string.Join(", ", temp_2[2]));
        }
    }
}
