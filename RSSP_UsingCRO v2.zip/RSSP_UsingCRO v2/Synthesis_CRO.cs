﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Synthesis_CRO
    {
        public Population pop = new Population();
        Repair rep = new Repair();
        private int[] m_new ;

        public int[] M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }
        //uniform
        public int[] synthesis(int[] m1, int[] m2)
        {
            Random rand = new Random();
            m_new = new int[m1.Length];
            for (int i =0; i<m1.Length; i++)
            {

                //double r = rand.NextDouble();
                int r = m2[i] % 2;
                
                if (r == 0)
                {
                    m_new[i] = m1[i];
                }
                else
                {
                        m_new[i] = m2[i];
                }
            }
            m_new = rep.repair_operator(m_new);
                return m_new;
            
            
        }
    }
}
