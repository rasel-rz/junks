﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class SinglePointOperator
    {
        private Repair rep = new Repair();

        private List<int[]> M_new { get; set; } = new List<int[]>();
        //single point operator
        public List<int[]> singlePointOp(int[] m11, int[] m22)
        {
            int[] m1 = new int[m11.Length];
            int[] m2 = new int[m11.Length];
            Random rand = new Random();
            int x1 = rand.Next(0, m1.Length);

            for (int i = 0; i < x1; i++)
            {
                m1[i] = m11[i];
            }
            for (int i = 0; i < m11.Length; i++)
            {
                m2[i] = m22[i];
            }
            for (int i = x1; i < m22.Length; i++)
            {
                m1[i] = m22[i];
            }
            for (int i = x1; i < m11.Length; i++)
            {
                m2[i] = m11[i];
            }
            
            m1 = rep.repair_operator(m1);
            m2 = rep.repair_operator(m2);
            M_new.Add(m1);
            M_new.Add(m2);

            return M_new;
        }
    }
}
