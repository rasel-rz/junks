﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LisT;

namespace RSSP_UsingCRO
{
    
    struct entry_table
    {
        public Int64 start;
        public Int64 end;
        public Int64 length;
    };
    class Population
    {
        
        

        private string input_location = "";
        private string align = "";

        

        private string sequence;
        private Int64 sequence_length;
        public List<string> molecule = new List<string>();
        public List<double> molecule_energy = new List<double>();
        public List<int[]> molecule_table = new List<int[]>();

        private List<int[]> Molecule_table
        {
            get { return molecule_table; }
            set { molecule_table = value; }
        }

        List<entry_table> ex = new List<entry_table>();
        
        List<entry_table> info_table = new List<entry_table>();
        List<entry_table> info_table1 = new List<entry_table>();
        List<entry_table> info_for_energy = new List<entry_table>();

        
        entry_table info = new entry_table(); 

        private Int64[,] zero_one = new Int64[2000, 2000];
        private Int64[,] zero_one_2 = new Int64[2000, 2000];

        

       

        public string Sequence
        {
            get { return sequence; }
            set { sequence = value; }
        }
        public Int64 Sequence_length
        {
            get { return sequence_length; }
            set { sequence_length = value; }
        }
        internal List<entry_table> Info_table
        {
            get { return info_table; }
            set { info_table = value; }
        }
        internal List<entry_table> Info_table1
        {
            get { return info_table1; }
            set { info_table1 = value; }
        }

        internal List<entry_table> Info_for_energy
        {
            get { return info_for_energy; }
            set { info_for_energy = value; }
        }
        internal entry_table Info
        {
            get { return info; }
            set { info = value; }
        }
        public Int64[,] Zero_one
        {
            get { return zero_one; }
            set { zero_one = value; }
        }
        public Int64[,] Zero_one_2
        {
            get { return zero_one_2; }
            set { zero_one_2 = value; }
        }
        public List<string> Molecule
        {
            get { return molecule; }
            set { molecule = value; }
        }
        public List<double> Molecule_energy
        {
            get { return molecule_energy; }
            set { molecule_energy = value; }
        }

        public string Input_location
        {
            get
            {
                return input_location;
            }

            set
            {
                input_location = value;
            }
        }

        public string Align
        {
            get
            {
                return align;
            }

            set
            {
                align = value;
            }
        }

        //public void siz(string sequence)
        //{
        //    sequence_length = sequence.Length;
        //}

        public void checkerboard(string sequence, int no_of_population, int condition_for_gu, int condition_for_count, string align, int condition_for_align)
        {
            int size = sequence.Count();
            sequence_length = sequence.Length;
            
            
            // finding out of 1...
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    if (j < i)
                    {
                        
                        if ( (sequence[i] == 'a' || sequence[i]== 'A') && (sequence[j] == 'u' || sequence[j] == 'U'))
                        {
                            zero_one[i, j] = 1;
                        }
                        if ((sequence[i] == 'u' || sequence[i] == 'U') && (sequence[j] == 'a' || sequence[j] == 'A'))
                        {
                            zero_one[i, j] = 1;
                        }
                        if ((sequence[i] == 'g' || sequence[i] == 'G') && (sequence[j] == 'u' || sequence[j] == 'U'))
                        {
                            zero_one[i, j] = 1;
                        }
                        if ((sequence[i] == 'u' || sequence[i] == 'U') && (sequence[j] == 'g' || sequence[j] == 'G'))
                        {
                            zero_one[i, j] = 1;
                        }
                        if ((sequence[i] == 'c' || sequence[i] == 'C') && (sequence[j] == 'g' || sequence[j] == 'G'))
                        {
                            zero_one[i, j] = 1;
                        }
                        if ((sequence[i] == 'g' || sequence[i] == 'G') && (sequence[j] == 'c' || sequence[j] == 'C'))
                        {
                            zero_one[i, j] = 1;
                        }
                        
                    }
                }
            }
            // finding the diagonal 1 and giving 0 to the found one, beside creating entry table.

            zero_one_2 = zero_one;
            Int64 count = 0;
            Int64 count1 = 0;
            int ccc = 0;
            int cccc = 0;
            

            for (int i= Convert.ToInt32(sequence_length) -1; i>0; i--)
            {
                //
                for (int j= 0; j<sequence_length-2; j++)
                {
                    if ((zero_one_2[i,j]==1) && (zero_one_2[(i-1),(j+1)]==1) )
                    {
                        count=0;
                        count1 = 0;
                        ccc = 0;
                        cccc = 0;


                        for(int k=0;;k++)
                        {
                            if (zero_one_2[(i-k),(j+k)]==1)
                            {
                                count++;
                                if ((sequence[i-k] == 'g' && sequence[j+k] =='u') || (sequence[i-k] == 'u' && sequence[j+k] == 'g'))
                                {
                                    count1++;
                                }
                               
                                zero_one_2[(i-k),(j+k)]=0;
                            }
                            else
                            {
                                break;
                            }
                        }
                        
                        if (count1 >= condition_for_gu  )
                        {
                            continue;
                        }
                        else if (count < condition_for_count)
                        {
                            continue;
                        }
                        else if (count>= condition_for_count && count1<condition_for_gu)
                        {
                            info.start = j;
                            info.end = i;
                            info.length = count;
                            info_table.Add(info);
                        }
                        
                        
                    }
                }
            }
            //sort entry table
            info_table1 = info_table;
            for (int i = 0; i < info_table1.Count; i++)
            {
                for (int j = i + 1; j < info_table1.Count; j++)
                {
                    if (info_table1[j].length > info_table1[i].length)
                    {
                        info = info_table1[i];
                        info_table1[i] = info_table1[j];
                        info_table1[j] = info;
                    }
                }
            }
            info_table = info_table1;
            info_table1 = new List<entry_table>();
            for (int i=0; i<info_table.Count; i++)
            {
                if (info_table[i].length<8)
                {
                    info_table1.Add(info_table[i]);
                }
            }
            //info table1 is the final info table of helices......................
            //permutation and sequence generate 
            for (int t=0; t<no_of_population; t++)
            {

                for (int i1 = 0; i1 < 4000; i1++)
                {
                    for (int i2 = 0; i2 < 2000; i2++)
                    {
                                                          //random delay time
                    }
                }


                int[] flag = new int[sequence_length];
                for (int i = 0; i < sequence_length; i++)
                {
                    flag[i] = 0;
                }
               // int no_of_sequence_permutation = (info_table1.Count);
                //int no_of_sequence_permutation = (info_table1.Count/2)+(info_table1.Count/4);
                int no_of_sequence_permutation = (info_table1.Count) ;
                int[] number_sequence = new int[no_of_sequence_permutation];
                number_sequence = sequence_generate(info_table1.Count, no_of_sequence_permutation);
                molecule_table.Add(number_sequence);
                
                
                char[] mol = new char[sequence_length];
                for (int i = 0; i < sequence_length; i++)
                {
                    mol[i] = '.';
                }
                info_for_energy = new List<entry_table>();
                int c_for_a = 0;

                

                mol = rearrange(info_table1, sequence, align, number_sequence, mol,condition_for_align);
                
                
                
                
                //sort info for energy 
                for (int i = 0; i < info_for_energy.Count; i++)
                {
                    for (int j = i+1; j < info_for_energy.Count; j++)
                    {
                        if (info_for_energy[j].start < info_for_energy[i].start)
                        {
                            info = info_for_energy[i];
                            info_for_energy[i] = info_for_energy[j];
                            info_for_energy[j] = info;
                        }
                    }
                }


                int found_multiple = 0;
                int no_of_stem = 0;
                double ener = 0;
                double to_ener = 0;
                for (int i = 0; i < info_for_energy.Count - 1; i++)
                {
                    if (info_for_energy[i].start + 1 == info_for_energy[i + 1].start)
                    {
                        found_multiple = 1;
                        if (no_of_stem == 0 && ((sequence[Convert.ToInt16(info_for_energy[i].start)] == 'a' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'a') || (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'g' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'g')))
                        {
                            ener += 0.45;
                        }

                        
                        no_of_stem++;
                        ener += calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);
                        
                    }
                    if ((info_for_energy[i].start + 1 != info_for_energy[i + 1].start) && (found_multiple == 1))
                    {
                        //ener += 4.09;
                        to_ener += ener;
                        ener = 0;
                        no_of_stem = 0;
                        found_multiple = 0;
                    }
                }
                to_ener += 4.09;




                molecule_energy.Add(to_ener);
                string mo = null;
                for (int i = 0; i < sequence_length; i++)
                {
                    mo += mol[i];
                }
                molecule.Add(mo);

            }

            
            
        }

        private double calculate_energy(char p1, char p2, char p3, char p4)
        {
            double ene = 0;
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.10;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.55;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.36;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.08;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.24;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.33;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.0;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.27;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'a' && p4 == 'u'))
            {
                ene = -2.35;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 's' && p3 == 'u' && p4 == 's'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'a' && p4 == 'u') || (p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.11;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.51;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -.5;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'g'))
            {
                ene = +1.29;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.41;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.53;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = +.3;
                return ene;
            }
            if ((p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'c'))
            {
                ene = -2.36;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'c' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.42;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.26;
                return ene;
            }
            
            return ene;
        }
        

        public int [] sequence_generate(int size,int no_of_permutation)
        {
            int[] numbers = new int[size];
            for (int i = 0; i < size; i++)
            {
                numbers[i] = i;
            }

            Random rnd = new Random();
            int[] number_sequence1 = numbers.OrderBy(x => rnd.Next()).ToArray();
            int[] number_sequence = new int[no_of_permutation];
            for (int i = 0; i < no_of_permutation; i++)
            {
                number_sequence[i] = number_sequence1[i];
                //System.IO.File.AppendAllText(@"E:\Thesis_RSP\RSSP_UsingCRO 1.0\RSSP_UsingCRO\bin\Debug\Final Sequence\output\test.txt", number_sequence[i].ToString() + "\n");
            }
            return number_sequence;
            
        }
        
        public char[] rearrange (List<entry_table>info_table1, string sequence, string align, int [] number_sequence, char[] mol, int condition_for_align)
        {

            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }

            info_for_energy = new List<entry_table>();
            int c_for_a = 0;

            //adding parenthesis
            for (int i = 0; i < number_sequence.Length; i++)
            {
                for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                {

                    if (flag[i1] == 0 && flag[j1] == 0)
                    {
                        if ((align[Convert.ToInt16(i1)] == '.' || align[Convert.ToInt16(j1)] == '.') && c_for_a > condition_for_align)
                        {
                            flag[i1] = 1;

                            flag[j1] = 1;
                            continue;

                        }
                        else if ((align[Convert.ToInt16(i1)] == '.' || align[Convert.ToInt16(j1)] == '.') && c_for_a < condition_for_align)
                        {
                            flag[i1] = 1;
                            mol[i1] = '(';
                            flag[j1] = 1;
                            mol[j1] = ')';
                            info.start = i1;
                            info.end = j1;
                            info_for_energy.Add(info);
                            c_for_a++;

                        }
                        else if ((align[Convert.ToInt16(i1)] == '(' && align[Convert.ToInt16(j1)] == ')'))
                        {

                            flag[i1] = 1;
                            mol[i1] = '(';
                            flag[j1] = 1;
                            mol[j1] = ')';
                            info.start = i1;
                            info.end = j1;
                            info_for_energy.Add(info);


                        }

                    }
                }

            }
            return mol;

        }

    }
}
