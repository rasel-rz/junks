﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{

    class CRO_RSSP
    {
        List<entry_table> info_table = new List<entry_table>();
        List<entry_table> info_table1 = new List<entry_table>();
        List<entry_table> info_for_energy = new List<entry_table>();
        List<string> temp = new List<string>();
        entry_table info = new entry_table();
        private string align = "";
       


        private Int64[,] zero_one = new Int64[1000, 1000];
        private Int64[,] zero_one_2 = new Int64[1000, 1000];

        double sensitivity;
        double specificity;
        double f_measure;
        double true_basepair;
        double false_negative_basepair;
        double false_positive_basepair;
        int popsize;
        double KELossRate;
        double MoleColl;
        double InitialKE;
        double buffer;
        int alpha;
        int beta;
        public  string sequence = null;
        public int minimum_energy_index;
        public CRO_RSSP (int popsize,double KELossRate, double MoleColl, double InitialKE, int alpha, int beta, double buffer, string sequence, MoleCule_CRO mol)
        {
            this.mol = mol;
            this.popsize = popsize;
            this.sequence = sequence;
            this.KELossRate = KELossRate;
            this.MoleColl = MoleColl;
            this.InitialKE = InitialKE;
            this.alpha = alpha;
            this.beta = beta;
            this.buffer = buffer;
            
        }
        On_wall_CRO on_wall = new On_wall_CRO();
        Decomposition_CRO decompose = new Decomposition_CRO();
        Inter_molecular_ineffective_CRO inter_molecular = new Inter_molecular_ineffective_CRO();
        
        Synthesis_CRO synthesis = new Synthesis_CRO();
        public MoleCule_CRO mol = new MoleCule_CRO();

        public string Align
        {
            get
            {
                return align;
            }

            set
            {
                align = value;
            }
        }

        public void OnwallIneffectiveCollision(int[] w, int index)
        {
            temp = new List<string>();
            Random rand = new Random();
            int[] w1 = on_wall.On_wall(w);
            double pe_new = calculatePE(w1);
            string mole_in_brace = temp[0];

            //Console.WriteLine(mole_in_brace.ToString());
            Console.WriteLine(temp.Count);

            double ke_new;
            mol.Numhit[index] = mol.Numhit[index] + 1;
            double t = mol.PE1[index] + mol.KE1[index];
            if (t>=pe_new)
            {
                double a = (rand.NextDouble() * (1-KELossRate))+KELossRate;
                ke_new = (mol.PE1[index] - pe_new + mol.KE1[index])*a;
                mol.Molecule_list[index] = w1;
                mol.PE1[index] = pe_new;
                mol.Mole_in_brace[index] = mole_in_brace;
              //  Console.WriteLine("ON " + mol.PE1[index]); 
                mol.KE1[index] = ke_new;
                if(mol.PE1[index]<mol.MinPE[index])
                {
                    //  Console.WriteLine("ON " + mol.PE1[index]); 
                    mol.minstruct[index] = w;
                    mol.MinPE[index] = mol.PE1[index];
                    mol.Minhit[index] = mol.Numhit[index];
                }
            }
        }

       public void Decomposition (int[] w1,int [] w2, int index1,int index2)
        {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
            nw = decompose.decomposition(w1,w1);
            int[] nw1 = nw[0];
            int[] nw2 = nw[1];
            Random rand = new Random();
            double pe1;
            double pe2;
            double e_dec;
            
            double gama1, gama2, gama3;
            gama1 = rand.NextDouble();
            gama2 = rand.NextDouble();
            pe1 = calculatePE(nw1);
            pe2 = calculatePE(nw2);

            string mole_in_brace1 = temp[0];
            string mole_in_brace2 = temp[1];

            //Console.WriteLine(mole_in_brace1.ToString());
            //Console.WriteLine("dec " + pe1 + " " + pe2); 

            if ((mol.PE1[index] + mol.KE1[index])>= (pe1+pe2))
           {
               e_dec = (mol.PE1[index] + mol.KE1[index]) - (pe1 + pe2);
           }
           else
           {
               
               e_dec = (mol.PE1[index] + mol.KE1[index]) + gama1 * gama2 * buffer - (pe1 + pe2);
           }
           if (e_dec>=0)
           {
               buffer = buffer * (1 -( gama1*gama2));
               gama3 = rand.NextDouble();

               mol.Molecule_list.RemoveAt(index);
               mol.PE1.RemoveAt(index);
               mol.KE1.RemoveAt(index);
               mol.Numhit.RemoveAt(index);
               mol.Minhit.RemoveAt(index);
               mol.minstruct.RemoveAt(index);
               mol.MinPE.RemoveAt(index);

               mol.Molecule_list.Add(nw1);
               mol.PE1.Add(pe1);
               mol.Mole_in_brace.Add(mole_in_brace1);
               mol.KE1.Add(e_dec * gama3);
               mol.Numhit.Add(0);
               mol.Minhit.Add(0);
               mol.minstruct.Add(nw1);
               mol.MinPE.Add(pe1);

                

               mol.Molecule_list.Add(nw2);
               mol.PE1.Add(pe2);
               mol.Mole_in_brace.Add(mole_in_brace2);
               mol.KE1.Add(e_dec *(1- gama3));
               mol.Numhit.Add(0);
               mol.Minhit.Add(0);
               mol.minstruct.Add(nw2);
               mol.MinPE.Add(pe2);
               Console.WriteLine("decomposition");
           }
           else
           {
               mol.Numhit[index] = mol.Numhit[index] + 1;
           }

        }
        
        public void IntermolecularIneffectiveCollision(int [] w1, int [] w2, int index1, int index2)
       {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
           nw = inter_molecular.inter_molecular_ineffective(w1, w2);
           int[] nw1 = nw[0];
           int[] nw2 = nw[1];
           Random rand = new Random();
           double pe1;
           double pe2;
           double e_inter;

           double gama4;
           gama4 = rand.NextDouble();
           
           pe1 = calculatePE(nw1);
            string mole_in_brace1 = temp[0] ;
           pe2 = calculatePE(nw2);
            string mole_in_brace2 = temp[1];

            //Console.WriteLine(mole_in_brace1.ToString());

            mol.Numhit[index1] = mol.Numhit[index1] + 1;
            mol.Numhit[index2] = mol.Numhit[index2] + 1;
            e_inter = (mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - (pe1 + pe2);
            if (e_inter>=0)
            {
                mol.Molecule_list[index1] = nw1;
                mol.Molecule_list[index2] = nw2;
                mol.PE1[index1] = pe1;
                mol.PE1[index2] = pe2;
                mol.Mole_in_brace[index1] = mole_in_brace1;
                mol.Mole_in_brace[index2] = mole_in_brace2;
               
                //Console.WriteLine("INT " + mol.PE1[index1] + " " + mol.PE1[index2]); 
                mol.KE1[index1] = e_inter * gama4;
                mol.KE1[index2] = e_inter * (1 - gama4);
                if (mol.PE1[index1]<mol.MinPE[index1])
                {
                    mol.minstruct[index1] = mol.Molecule_list[index1];
                    mol.MinPE[index1] = mol.PE1[index1];
                    mol.Minhit[index1] = mol.Numhit[index1];
                }
                if (mol.PE1[index2]<mol.MinPE[index2])
                {
                    mol.minstruct[index2] = mol.Molecule_list[index2];
                    mol.MinPE[index2] = mol.PE1[index2];
                    mol.Minhit[index2] = mol.Numhit[index2];
                }
            }
       }
        
        public void Synthesis (int [] w1, int [] w2, int index1, int index2)
        {
            temp = new List<string>();
            int[] nw = synthesis.synthesis(w1, w2);
            double pe_new = calculatePE(nw);
            string mol_in_brace = temp[0];
           // Console.WriteLine(mol_in_brace.ToString());
           // Console.WriteLine("SYN "+pe_new);

            double ke_new;
            if((mol.PE1[index1]+mol.PE1[index2] + mol.KE1[index1]+mol.KE1[index2])>=pe_new)
            {
                mol.Molecule_list.RemoveAt(index1);
                mol.PE1.RemoveAt(index1);
                mol.KE1.RemoveAt(index1);
                mol.Numhit.RemoveAt(index1);
                mol.Minhit.RemoveAt(index1);
                mol.minstruct.RemoveAt(index1);
                mol.MinPE.RemoveAt(index1);

                mol.Molecule_list.RemoveAt(index2);
                mol.PE1.RemoveAt(index2);
                mol.KE1.RemoveAt(index2);
                mol.Numhit.RemoveAt(index2);
                mol.Minhit.RemoveAt(index2);
                mol.minstruct.RemoveAt(index2);
                mol.MinPE.RemoveAt(index2);

                mol.Molecule_list.Add(nw);
                mol.PE1.Add(pe_new);
                mol.Mole_in_brace.Add(mol_in_brace);
                mol.KE1.Add((mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - pe_new);
                mol.Numhit.Add(0);
                mol.Minhit.Add(0);
                mol.minstruct.Add(nw);
                mol.MinPE.Add(pe_new);
                Console.WriteLine("Synthesis");
            }
            else
            {
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
            }
        }
         
        
        public void cro (int popsize, double KELossRate, double MoleColl, double buffer, double initialKE, int alpha, int beta, int iteration, MoleCule_CRO mol, string file_input, string input_location_for_alignment, string output_location )
        {
            Random rand = new Random();
            align = System.IO.File.ReadAllText(input_location_for_alignment + file_input + ".txt");
            //   mol.molecule(sequence, popsize, initialKE);
            double b = 0;
            int i = 0;
            int[] w;
            int[] w1;
            int[] w2;
            int index, index1, index2;
            double minimum_energ = 1000;
            int tt=0;
            for (int j = 0; j < mol.PE1.Count; j++)
            {
                //System.IO.File.AppendAllText("o7.txt", (mol.PE1[j] + "\n "));
                if (mol.PE1[j] < minimum_energ)
                {
                    minimum_energ = mol.PE1[j];
                    tt = j;
                }
            }
           // System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + " before "+ tt.ToString() +"\n");

            
            int on, dec, inef, syn;
            on = 0; dec = 0; inef = 0; syn = 0;

            for (i=0; i<iteration; i++)
            {
                //call for operator
                index1 = rand.Next(0, mol.PE1.Count);
                Console.WriteLine(index1);
                index2 = rand.Next(0, mol.PE1.Count);
                Console.WriteLine(index2);
                Decomposition(mol.Molecule_list[index1], mol.Molecule_list[index2],index1,index2);

                Console.WriteLine("Iteration         " + i);
                b = rand.NextDouble();
                if (b>MoleColl)
                {
                    index= rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index);

                    if ((mol.Numhit[index]-mol.Minhit[index])>alpha)
                    {
                        dec++;
                       
                        Decomposition(mol.Molecule_list[index], index);

                    }
                    else
                    {
                        on++;
                        
                        OnwallIneffectiveCollision(mol.Molecule_list[index], index);
                    }
                }
                else
                {
                    index1 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index1);
                    for (int ii = 0; ii < 10000; ii++ )
                    {
                        for (int jj=0; jj<10000; jj++)
                        {
                            
                        }

                    }
                    index2 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index2);
                    if ((mol.KE1[index1]+mol.KE1[index2])<beta)
                    {
                        syn++;
                       
                        Synthesis(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }
                    else
                    {
                        inef++;
                        
                        IntermolecularIneffectiveCollision(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }
                }
            }
            //minimum energy findout;
            minimum_energ = 1000;
            mol.PE1 = mol.PE1;

            for (int j=0; j<mol.PE1.Count; j++)
            {
                //System.IO.File.AppendAllText("o8.txt", (mol.PE1[j] + "\n "));
                if (mol.PE1[j]<minimum_energ)
                {
                    minimum_energ = mol.PE1[j];
                    minimum_energy_index = j;
                }
            }

            //the structure of minimum energy;


            // System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + "   "+minimum_energy_index+" \nOn wall =  " + on.ToString() + "\nDecomposition = " + dec.ToString() +
            //    " \nIntermollecular Ineffective = "+ inef.ToString()+"\nSynthesis = "+syn.ToString()+"\nPopulation size = "+popsize+"\nIteration = "+iteration+"\n");
             System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + "   "+minimum_energy_index+" \n");


            //int[] flag = new int[sequence.Length];
            //for (int i1 = 0; i1 < sequence.Length; i1++)
            //{
            //    flag[i1] = 0;
            //}
            //int no_of_sequence_permutation = (info_table1.Count);/// 2) + (info_table1.Count / 4);
            //int[] number_sequence = new int[no_of_sequence_permutation]; 
            //number_sequence = mol.minstruct[minimum_energy_index];

            //Console.WriteLine(number_sequence);

            //char[] moll = new char[sequence.Length];
            //for (int i1 = 0; i1 < sequence.Length; i1++)
            //{
            //    moll[i1] = '.';
            //}
            //info_for_energy = new List<entry_table>();
            ////adding parenthesis
            //for (int i2 = 0; i2 < number_sequence.Length; i2++)
            //{

            //    for (Int64 i1 = info_table1[number_sequence[i2]].start, j1 = info_table1[number_sequence[i2]].end; i1 < (info_table1[number_sequence[i2]].length + info_table1[number_sequence[i2]].start); i1++, j1--)
            //    {

            //        if (flag[i1] == 0 && flag[j1] == 0)
            //        {

            //            flag[i1] = 1;
            //            moll[i1] = '(';
            //            flag[j1] = 1;
            //            moll[j1] = ')';
            //            info.start = i1;
            //            info.end = j1;
            //            info_for_energy.Add(info);
            //        }
            //    }

            //}
            string final = null;
            //for (int i1 = 0; i1 <sequence.Length; i1++)
            //{
            //    final += moll[i1];
            //}
            final = mol.Mole_in_brace[minimum_energy_index];
            //counting base pairs with regarding the given sequence.
            
            
            //Console.WriteLine(align);
            Console.WriteLine(final);
            true_basepair = 0;
            false_negative_basepair = 0;
            false_positive_basepair = 0;
            for (int i1 = 0; i1 < sequence.Length; i1++ )
            {
                if (align[i1] == final[i1] && align[i1] == '(')
                {
                    true_basepair++;
                }
                if (align[i1] == '(' && final[i1] != '(')
                {
                    false_negative_basepair++;
                }
                if (align[i1]!='(' && final[i1] =='(')
                {
                    false_positive_basepair++;
                }
            }

            sensitivity =( true_basepair/ (true_basepair + false_negative_basepair))*100.0;
            Console.WriteLine(sensitivity);
            specificity =( true_basepair / (true_basepair + false_positive_basepair))*100.0;
            Console.WriteLine(specificity);
            double a, c;
            a = sensitivity * specificity * 2;
            c = sensitivity + specificity;
            f_measure = a / c;
            //f_measure =( (2 * specificity * specificity) / (specificity + sensitivity));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (align + " \n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (final + " \n"));

            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("TP = " + true_basepair + " FP = " + false_positive_basepair + "  FN = " + false_negative_basepair + "\n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("Sensitivity = " + sensitivity + " Specificity = " + specificity + "  F-measure = " + f_measure + "\n"));
                        
        }



        public double calculatePE(int[] w)
        {
           
            int size = sequence.Count();
            int sequence_length = sequence.Length;

          
            info_table1 = mol.Info_table;

            int[] flag = new int[sequence_length];
            for (int i = 0; i < sequence_length; i++)
            {
                flag[i] = 0;
            }
            int[] number_sequence = new int[w.Length];
            number_sequence = w;

            char[] moll = new char[sequence_length];
            for (int i = 0; i < sequence_length; i++)
            {
                moll[i] = '.';
            }
            info_for_energy = new List<entry_table>();
            int c_for_a = 0;

            moll = rearange(info_table1,sequence, align, number_sequence, moll, mol.Condition_for_align);
           
            //adding parenthesis
            //try
            //{
            //    for (int i = 0; i < number_sequence.Length; i++)
            //    {
            //        for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
            //        {

            //            if (flag[i1] == 0 && flag[j1] == 0)
            //            {

            //                if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && c_for_a > mol.Condition_for_align)
            //                {
            //                    flag[i1] = 1;
            //                    flag[j1] = 1;
            //                    continue;

            //                }
            //                else if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && mol.Condition_for_align > c_for_a)
            //                {
            //                    flag[i1] = 1;
            //                    moll[i1] = '(';
            //                    flag[j1] = 1;
            //                    moll[j1] = ')';
            //                    info.start = i1;
            //                    info.end = j1;
            //                    info_for_energy.Add(info);
            //                    c_for_a++;

            //                }
            //                else if ((Align[Convert.ToInt16(i1)] == '(' && Align[Convert.ToInt16(j1)] == ')'))
            //                {

            //                    flag[i1] = 1;
            //                    moll[i1] = '(';
            //                    flag[j1] = 1;
            //                    moll[j1] = ')';
            //                    info.start = i1;
            //                    info.end = j1;
            //                    info_for_energy.Add(info);


            //                }
            //            }
            //        }

            //    }
            //}
            //catch (Exception)
            //{

                
            //}


            //sort info for energy 
            for (int i = 0; i < info_for_energy.Count; i++)
            {
                for (int j = i + 1; j < info_for_energy.Count; j++)
                {
                    if (info_for_energy[j].start < info_for_energy[i].start)
                    {
                        info = info_for_energy[i];
                        info_for_energy[i] = info_for_energy[j];
                        info_for_energy[j] = info;
                    }
                }
            }

            int found_multiple = 0;
            int no_of_stem = 0;
            double ener = 0;
            double to_ener = 0;
            for (int i=0; i<info_for_energy.Count-1; i++)
            {
                if (info_for_energy[i].start+1 == info_for_energy[i+1].start)
                {
                    found_multiple = 1;
                    if (no_of_stem==0 && ((sequence[Convert.ToInt16(info_for_energy[i].start)] == 'a' && sequence[Convert.ToInt16(info_for_energy[i].end)]=='u')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'a')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'g' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'u')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'g')))
                    {
                        ener += 0.45;
                    }
                    
                    no_of_stem++;
                    ener+= calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);
                    //try
                    //{
                    //    if (info_for_energy[i + 1].start + 1 == info_for_energy[i + 2].start && ((sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'a' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'a') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'g' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'g')))
                    //    {
                    //        ener += 0.45;
                    //    }
                    //}
                    //catch (Exception ex)
                    //{


                    //}
                }
                if ((info_for_energy[i].start + 1 != info_for_energy[i + 1].start) && (found_multiple == 1))
                {
                    //ener += 4.09;
                    to_ener += ener;
                    ener = 0;
                    no_of_stem = 0;
                    found_multiple = 0;
                }
            }
            to_ener += 4.09; 











            //int flag3 = 0; int flag1 = 0; int flag2 = 0; double total_energy = 0;
            //double energy = 0;
            //int flag4 = 0;
            //int[] array_for_delete_brace = new int[sequence.Length];
            //for (int i = 0; i < sequence.Length; i++)
            //{
            //    array_for_delete_brace[i] = 1;
            //}

            //int threshold_energy = -50;
            ////energy calculation
            //for (int i = 0; i < info_for_energy.Count - 1; i++)
            //{
            //    if ((info_for_energy[i].start + 1) == info_for_energy[i + 1].start)    // multiple (( ache naki check kora hocche. single thakle stem hobe na tai ...
            //    {
            //        array_for_delete_brace[Convert.ToInt32(info_for_energy[i].start)] = 2;
            //        array_for_delete_brace[Convert.ToInt32(info_for_energy[i].end)] = 2;
            //        flag3 = 1; flag4 = 1;
            //        //flag2 == prothom input naki check korar jonno.
            //        //flag1 == ekta au/gu penalty paoa geche.
            //        //flag4 == sesh hoye geche ekta stem
            //        if (flag2 == 0 && ((sequence[Convert.ToInt32(info_for_energy[i].start)] == 'a') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'A') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'U') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'g' && sequence[Convert.ToInt32(info_for_energy[i].end)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt32(info_for_energy[i].end)] == 'g')))
            //        {
            //            flag1 = 1;
            //            flag2 = 1;
            //            energy += .45;
            //            energy += calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);
            //            //double te = calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);

            //            // Console.WriteLine(te + " from ");
            //        }
            //        else
            //        {
            //            energy += calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);

            //            //double te = calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);
            //            // Console.WriteLine(te + " from base");
            //        }
            //    }
            //    else
            //    {
            //        flag4 = 2;
            //        if (flag3 == 1) // sequential multiple basepair paoa geche and sesh hoye geche ekta helix
            //        {
            //            if (((sequence[Convert.ToInt32(info_for_energy[i].start)] == 'a') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'A') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'U') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'g' && sequence[Convert.ToInt32(info_for_energy[i].end)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt32(info_for_energy[i].end)] == 'g')))
            //            {

            //                energy += .45;
            //                // energy += .43; //for symmetric or self complementary
            //                energy += 4.09;
            //                // Console.WriteLine(energy + " 1");

            //                if (energy < threshold_energy)
            //                {

            //                    flag2 = 0;
            //                    flag1 = 0;

            //                    for (int ii = 0; ii < sequence.Length; ii++)
            //                    {
            //                        if (array_for_delete_brace[ii] == 2)
            //                        {
            //                            //Console.WriteLine("haha");
            //                            moll[ii] = '.';
            //                            array_for_delete_brace[ii] = 1;
            //                        }

            //                    }
            //                }
            //                else
            //                {
            //                    for (int i4 = 0; i4 < sequence.Length; i4++)
            //                    {
            //                        array_for_delete_brace[i4] = 1;
            //                    }
            //                    total_energy += energy;
            //                    energy = 0;
            //                    flag2 = 0;
            //                    flag1 = 0;
            //                }


            //            }
            //            else
            //            {
            //                if (flag1 == 1)
            //                {
            //                    //energy += .43;  //for symmetric or self complementary
            //                    energy += 4.09;
            //                    // Console.WriteLine(energy + " 2");
            //                    if (energy < threshold_energy)
            //                    {

            //                        for (int ii = 0; ii < sequence.Length; ii++)
            //                        {
            //                            if (array_for_delete_brace[ii] == 2)
            //                            {
            //                                //Console.WriteLine("haha2");
            //                                moll[ii] = '.';
            //                                array_for_delete_brace[ii] = 1;
            //                            }

            //                        }

            //                        flag2 = 0;
            //                        flag1 = 0;
            //                    }
            //                    else
            //                    {
            //                        for (int i4 = 0; i4 < sequence.Length; i4++)
            //                        {
            //                            array_for_delete_brace[i4] = 1;
            //                        }
            //                        total_energy += energy;
            //                        energy = 0;
            //                        flag2 = 0;
            //                        flag1 = 0;
            //                    }


            //                }
            //                else if (flag1 != 1)
            //                {
            //                    energy += 4.09;
            //                    //Console.WriteLine(energy + " 3");


            //                    if (energy < threshold_energy)
            //                    {

            //                        for (int ii = 0; ii < sequence.Length; ii++)
            //                        {
            //                            if (array_for_delete_brace[ii] == 2)
            //                            {
            //                                //Console.WriteLine("haha3");
            //                                moll[ii] = '.';
            //                                array_for_delete_brace[ii] = 1;
            //                            }

            //                        }

            //                        flag2 = 0;
            //                        flag1 = 0;
            //                    }
            //                    else
            //                    {
            //                        for (int i4 = 0; i4 < sequence.Length; i4++)
            //                        {
            //                            array_for_delete_brace[i4] = 1;
            //                        }
            //                        total_energy += energy;
            //                        energy = 0;
            //                        flag2 = 0;
            //                        flag1 = 0;
            //                    }
            //                }
            //            }
            //            flag3 = 0;
            //        }

            //    }
            //}
            //if (flag4 != 2)
            //{
            //    if (flag3 == 1)
            //    {
            //        if (((sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'a') || (sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'A') || (sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'U') || (sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'g' && sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].end)] == 'u') || (sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].start)] == 'u' && sequence[Convert.ToInt32(info_for_energy[info_for_energy.Count - 1].end)] == 'g')))
            //        {

            //            energy += .45;
            //            energy += .43;
            //            energy += 4.09;
            //            //Console.WriteLine(energy + " 1");
            //            total_energy += energy;
            //            energy = 0;
            //            flag2 = 0;
            //            flag1 = 0;
            //        }
            //        else
            //        {
            //            if (flag1 == 1)
            //            {
            //                energy += .43;
            //                energy += 4.09;
            //                //Console.WriteLine(energy + " 2");
            //                total_energy += energy;
            //                energy = 0;
            //                flag2 = 0;
            //                flag1 = 0;
            //            }
            //            else if (flag1 != 1)
            //            {
            //                energy += 4.09;
            //                // Console.WriteLine(energy + " 3");
            //                total_energy += energy;
            //                energy = 0;
            //                flag2 = 0;
            //                flag1 = 0;
            //            }
            //        }
            //        flag3 = 0;
            //    }
            //}
            string mo = null;
            for (int i = 0; i < sequence_length; i++)
            {
                mo += moll[i];
            }
            temp.Add(mo);
            //Console.WriteLine(total_energy+" method");
            return to_ener;

        }

        //these are important
        public char[] rearange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] mol, int condition_for_align)
        {
            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }
            info_for_energy = new List<entry_table>();
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {

                        if (flag[i1] == 0 && flag[j1] == 0)
                        {

                            flag[i1] = 1;
                            mol[i1] = '(';
                            flag[j1] = 1;
                            mol[j1] = ')';
                            info.start = i1;
                            info.end = j1;
                            info_for_energy.Add(info);
                        }
                    }

                }
            }
            catch (Exception )
            {
                
                
            }
            return mol;
        }

        //these are important
        private double calculate_energy(char p1, char p2, char p3, char p4)
        {
            double ene = 0;
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.10;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.55;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.36;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.08;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.24;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.33;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.0;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.27;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'a' && p4 == 'u'))
            {
                ene = -2.35;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 's' && p3 == 'u' && p4 == 's'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'a' && p4 == 'u') || (p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.11;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.51;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -.5;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'g'))
            {
                ene = +1.29;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.41;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.53;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = +.3;
                return ene;
            }
            if ((p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'c'))
            {
                ene = -2.36;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'c' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.42;
                return ene;
            }
            //if ((p1 == 'u' && p2 == 'u' && p3 == 'u' && p4 == 'u'))    //hfdhgdhgd
            //{
            //    ene = 0;
            //    return ene;
            //}
            if ((p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.26;
                return ene;
            }
            return ene;
        }

        //These are important

        public char[] rearrange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] moll, int condition_for_align)
        {

            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }

            info_for_energy = new List<entry_table>();
            int c_for_a = 0;

            //adding parenthesis
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {

                        if (flag[i1] == 0 && flag[j1] == 0)
                        {

                            if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && c_for_a > mol.Condition_for_align)
                            {
                                flag[i1] = 1;
                                flag[j1] = 1;
                                continue;

                            }
                            else if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && mol.Condition_for_align > c_for_a)
                            {
                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);
                                c_for_a++;

                            }
                            else if ((Align[Convert.ToInt16(i1)] == '(' && Align[Convert.ToInt16(j1)] == ')'))
                            {

                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);


                            }
                        }
                    }

                }
            }
            catch (Exception)
            {


            }
            return moll;

        }



    }
}
