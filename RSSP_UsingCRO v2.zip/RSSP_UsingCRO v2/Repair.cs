﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Repair
    {
        private int[] m_new;

        public int[] New
        {
            get
            {
                return m_new;
            }

            set
            {
                m_new = value;
            }
        }
        public int [] repair_operator (int [] m)
        {
            int[] m_new = m.Distinct().ToArray();
            return m_new;
        }
    }
}
