﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class UniformOperator
    {
        Repair rep = new Repair();

        public int[] M_new { get; set; }
        
        public int[] uniformOp(int[] m1, int[] m2)
        {
            Random rand = new Random();
            M_new = new int[m1.Length];
            for (int i = 0; i < m1.Length; i++)
            {
                int r = m2[i] % 2;

                if (r == 0)
                {
                    M_new[i] = m1[i];
                }
                else
                {
                    M_new[i] = m2[i];
                }
            }
            M_new = rep.repair_operator(M_new);
            return M_new;
        }
    }
}
