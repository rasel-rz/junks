﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class On_wall_CRO
    {
        public Population pop = new Population();
        Repair rep = new Repair();
        private int[] m_new = new int[10000];

        public int[] M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }

       public int [] On_wall (int [] m)
        {
            m_new = m;
            Random rand = new Random();
            int i,j;
            i = rand.Next(0, m.Length-1);
            j = rand.Next(0, m.Length-1);
            if (m[i] + j <= m.Length )
            {
                m_new[i] = m[i] + j;
            }
            else
            {
                if (m[i]>j)
                {
                    m_new[i] = m[i] - j;
                }
                else
                {
                    m_new[i] =  j - m[i];
                }
                
            }
            m_new = rep.repair_operator(m_new);
            return m_new;
        }

    }
}
