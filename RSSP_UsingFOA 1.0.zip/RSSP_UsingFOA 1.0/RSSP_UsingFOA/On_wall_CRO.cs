﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class On_wall_CRO
    {
        public Population pop = new Population();
        Repair rep = new Repair();
        private int[] m_new = new int[10000];

        public int[] M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }
        //EXE
       public int [] On_wall (int [] m)
        {
            m_new = m;
            Random rand = new Random();
            int i,j, k;
            //k= 20;
           // k = rand.Next(20);
            i = rand.Next(0, m.Length-1);
            j = rand.Next(0, m.Length-1);

            for (i = 0; i < m.Length; i++)
            {
                for (i = 0; i < 20; i++)
                {
                    int x = rand.Next(0, 100);
                
                    m[x]++;
                }
                m[i] = rand.Next(0, m.Length);
            }
            /* (m[i] + j <= m.Length )
            {
                m_new[i] = m[i] + j;
            }
            else
            {
                if (m[i]>j)
                {
                    m_new[i] = m[i] - j;
                }
                else
                {
                    m_new[i] =  j - m[i];
                }
                
            }*/
            m_new = rep.repair_operator(m_new);
            return m_new;
        }

    }
}
