﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class Uniform_operator
    {
        public Population pop = new Population();
        Repair rep = new Repair();
        private int[] m_new ;

        public int[] M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }

        public int[] uniform_operator(int[] m1, int[] m2)
        {
            Random rand = new Random();
            m_new = new int[m1.Length];
            for (int i =0; i<m1.Length; i++)
            {
                double r=0;
                try
                {
                     r = m2[i] % 2;
                }
                catch (Exception)
                {

                    //Console.Write("m2 " + m2[i] + " m_new " + m_new[i]);
                }
                if (r==0)
                {
                    m_new[i] = m1[i];
                }
                else
                {
                    try
                    {
                        m_new[i] = m2[i];
                    }
                    catch (Exception)
                    {

                        //Console.Write("m2 " + m2[i] + " m_new " + m_new[i]);
                    }
                }
            }
            m_new = rep.repair_operator(m_new);
                return m_new;
            
            
        }
    }
}
