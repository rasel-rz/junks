﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{

    class FOA_RSSP
    {
        
        
        List<entry_table> info_table = new List<entry_table>();
        List<entry_table> info_table1 = new List<entry_table>();
        List<entry_table> info_for_energy = new List<entry_table>();
        List<string> temp = new List<string>();
        entry_table info = new entry_table();
        private string align = "";
       


        private Int64[,] zero_one = new Int64[1000, 1000];
        private Int64[,] zero_one_2 = new Int64[1000, 1000];

        double sensitivity;
        double specificity;
        double f_measure;
        double true_basepair;
        double false_negative_basepair;
        double false_positive_basepair;
        int popsize;
        double KELossRate;
        double MoleColl;
        double InitialKE;
        double buffer;
        int alpha;
        int beta;

       public  string sequence = null;
       public int minimum_energy_index;
        public FOA_RSSP (int popsize,double KELossRate, double MoleColl, double InitialKE, int alpha, int beta, double buffer, string sequence, MoleCule_FOA mol)
        {
            this.mol = mol;
            this.popsize = popsize;
            this.sequence = sequence;
            this.KELossRate = KELossRate;
            this.MoleColl = MoleColl;
            this.InitialKE = InitialKE;
            this.alpha = alpha;
            this.beta = beta;
            this.buffer = buffer;
            
        }
        On_wall_CRO on_wall = new On_wall_CRO();
        Decomposition_CRO decompose = new Decomposition_CRO();
        Single_point_operator single_point = new Single_point_operator();
        Multiple_point_operator multiple_point = new Multiple_point_operator();
        Uniform_operator uniform = new Uniform_operator();
        public MoleCule_FOA mol = new MoleCule_FOA();
        Exe_operator exe = new Exe_operator();


        public string Align
        {
            get
            {
                return align;
            }

            set
            {
                align = value;
            }
        }

        public void FOA_try(string sequence)
        {
            Random random = new Random();
            int X = 1;
            int Y = 1;
            int X_i = X + random.Next(0, 50);
            int Y_i = Y + random.Next(0, 50);
            double Distance = Math.Sqrt((X_i * X_i) + (Y_i * Y_i));
            float Smell = (float)(1 / Distance);

            if(Smell < 0.5)
            {
                // Do your Single Point Operation Here on the @param sequence'
                float temp = random.Next(0, 100) / 100;
                if(temp < 0.6)
                {
                    // DO your Uniform Operation Here on the OUTPUT of Single Point Operator
                }
                else
                {
                    // DO your EXE Operation Here on the OUTPUT of Single Point Operator
                }
            }
            else
            {
                // Do your MultiPoint Operation Here on the @param 'sequence'
                float vision = random.Next(0, 100) / 100;
                if(vision < 0.7)
                {
                    // DO your EXE Operation Here on the OUTPUT of Single Point Operator
                }
                else
                {
                    // DO your Uniform Operation Here on the OUTPUT of Single Point Operator
                }
            }
        }

        public void OnwallIneffectiveCollision(int[] w, int index)
        {
            temp = new List<string>();
            Random rand = new Random();
            int[] w1 = on_wall.On_wall(w);
            double pe_new = calculatePE(w1);
            string mole_in_brace = temp[0];

            //Console.WriteLine(mole_in_brace.ToString());
            Console.WriteLine(temp.Count);

            double ke_new;
            mol.Numhit[index] = mol.Numhit[index] + 1;
            double t = mol.PE1[index] + mol.KE1[index];
            if (t>=pe_new)
            {
                double a = (rand.NextDouble() * (1-KELossRate))+KELossRate;
                ke_new = (mol.PE1[index] - pe_new + mol.KE1[index])*a;
                mol.Molecule_list[index] = w1;
                mol.PE1[index] = pe_new;
                mol.Mole_in_brace[index] = mole_in_brace;
              //  Console.WriteLine("ON " + mol.PE1[index]); 
                mol.KE1[index] = ke_new;
                if(mol.PE1[index]<mol.MinPE[index])
                {
                    //  Console.WriteLine("ON " + mol.PE1[index]); 
                    mol.minstruct[index] = w;
                    mol.MinPE[index] = mol.PE1[index];
                    mol.Minhit[index] = mol.Numhit[index];
                }
            }
        }

       public void Decomposition (int [] w, int index)
        {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
            nw = decompose.decomposition(w);
            int[] nw1 = nw[0];
            int[] nw2 = nw[1];
           Random rand = new Random();
            double pe1;
            double pe2;
            double e_dec;
            
            double gama1, gama2, gama3;
            gama1 = rand.NextDouble();
            gama2 = rand.NextDouble();
            pe1 = calculatePE(nw1);
            pe2 = calculatePE(nw2);

            string mole_in_brace1 = temp[0];
            string mole_in_brace2 = temp[1];

            //Console.WriteLine(mole_in_brace1.ToString());
            //  Console.WriteLine("dec " + pe1 + " " + pe2); 

            if ((mol.PE1[index] + mol.KE1[index])>= (pe1+pe2))
           {
               e_dec = (mol.PE1[index] + mol.KE1[index]) - (pe1 + pe2);
           }
           else
           {
               
               e_dec = (mol.PE1[index] + mol.KE1[index]) + gama1 * gama2 * buffer - (pe1 + pe2);
           }
           if (e_dec>=0)
           {
               buffer = buffer * (1 -( gama1*gama2));
               gama3 = rand.NextDouble();

               mol.Molecule_list.RemoveAt(index);
               mol.PE1.RemoveAt(index);
               mol.KE1.RemoveAt(index);
               mol.Numhit.RemoveAt(index);
               mol.Minhit.RemoveAt(index);
               mol.minstruct.RemoveAt(index);
               mol.MinPE.RemoveAt(index);

               mol.Molecule_list.Add(nw1);
               mol.PE1.Add(pe1);
                mol.Mole_in_brace.Add(mole_in_brace1);
               mol.KE1.Add(e_dec * gama3);
               mol.Numhit.Add(0);
               mol.Minhit.Add(0);
               mol.minstruct.Add(nw1);
               mol.MinPE.Add(pe1);

                

               mol.Molecule_list.Add(nw2);
               mol.PE1.Add(pe2);
                mol.Mole_in_brace.Add(mole_in_brace2);
               mol.KE1.Add(e_dec *(1- gama3));
               mol.Numhit.Add(0);
               mol.Minhit.Add(0);
               mol.minstruct.Add(nw2);
               mol.MinPE.Add(pe2);
                Console.WriteLine("decomposition");
           }
           else
           {
               mol.Numhit[index] = mol.Numhit[index] + 1;
           }

        }

        public void Exeoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            int[] nw = exe.exe_operator(w1, w2);
            double pe_new = calculatePE(nw);
            string mol_in_brace = temp[0];
            // Console.WriteLine(mol_in_brace.ToString());
            // Console.WriteLine("SYN "+pe_new);

            double ke_new;
            if ((mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) >= pe_new)
            {
                mol.Molecule_list.RemoveAt(index1);
                mol.PE1.RemoveAt(index1);
                mol.KE1.RemoveAt(index1);
                mol.Numhit.RemoveAt(index1);
                mol.Minhit.RemoveAt(index1);
                mol.minstruct.RemoveAt(index1);
                mol.MinPE.RemoveAt(index1);

                mol.Molecule_list.RemoveAt(index2);
                mol.PE1.RemoveAt(index2);
                mol.KE1.RemoveAt(index2);
                mol.Numhit.RemoveAt(index2);
                mol.Minhit.RemoveAt(index2);
                mol.minstruct.RemoveAt(index2);
                mol.MinPE.RemoveAt(index2);

                mol.Molecule_list.Add(nw);
                mol.PE1.Add(pe_new);
                mol.Mole_in_brace.Add(mol_in_brace);
                mol.KE1.Add((mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - pe_new);
                mol.Numhit.Add(0);
                mol.Minhit.Add(0);
                mol.minstruct.Add(nw);
                mol.MinPE.Add(pe_new);
                Console.WriteLine("Exe_operator");
            }
            else
            {
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
            }
        }


        public void Singlepointoperator(int [] w1, int [] w2, int index1, int index2)
       {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
           nw = single_point.single_point_operator(w1, w2);
           int[] nw1 = nw[0];
           int[] nw2 = nw[1];
           Random rand = new Random();
           double pe1;
           double pe2;
           double e_single;

           double gama4;
           gama4 = rand.NextDouble();
           
           pe1 = calculatePE(nw1);
            string mole_in_brace1 = temp[0] ;
           pe2 = calculatePE(nw2);
            string mole_in_brace2 = temp[1];

            //Console.WriteLine(mole_in_brace1.ToString());

            mol.Numhit[index1] = mol.Numhit[index1] + 1;
           mol.Numhit[index2] = mol.Numhit[index2] + 1;
            e_single = (mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - (pe1 + pe2);
            if (e_single>= 0)
            {
                mol.Molecule_list[index1] = nw1;
                mol.Molecule_list[index2] = nw2;
                mol.PE1[index1] = pe1;
                mol.PE1[index2] = pe2;
                mol.Mole_in_brace[index1] = mole_in_brace1;
                mol.Mole_in_brace[index2] = mole_in_brace2;
               
                //Console.WriteLine("INT " + mol.PE1[index1] + " " + mol.PE1[index2]); 
                mol.KE1[index1] = e_single * gama4;
                mol.KE1[index2] = e_single * (1 - gama4);
                if (mol.PE1[index1]<mol.MinPE[index1])
                {
                    mol.minstruct[index1] = mol.Molecule_list[index1];
                    mol.MinPE[index1] = mol.PE1[index1];
                    mol.Minhit[index1] = mol.Numhit[index1];
                }
                if (mol.PE1[index2]<mol.MinPE[index2])
                {
                    mol.minstruct[index2] = mol.Molecule_list[index2];
                    mol.MinPE[index2] = mol.PE1[index2];
                    mol.Minhit[index2] = mol.Numhit[index2];
                }
                Console.WriteLine("single_point");
            }
       }
        //multiple point  1
        public void Multiplepointoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
            nw = multiple_point.multiple_point_operator(w1, w2);
            int[] nw1 = nw[0];
            int[] nw2 = nw[1];
            Random rand = new Random();
            double pe1;
            double pe2;
            double e_multi;

            double gama4;
            gama4 = rand.NextDouble();

            pe1 = calculatePE(nw1);
            string mole_in_brace1 = temp[0];
            pe2 = calculatePE(nw2);
            string mole_in_brace2 = temp[1];

            //Console.WriteLine(mole_in_brace1.ToString());

            mol.Numhit[index1] = mol.Numhit[index1] + 1;
            mol.Numhit[index2] = mol.Numhit[index2] + 1;
            e_multi = (mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - (pe1 + pe2);
            if (e_multi >= 0)
            {
                mol.Molecule_list[index1] = nw1;
                mol.Molecule_list[index2] = nw2;
                mol.PE1[index1] = pe1;
                mol.PE1[index2] = pe2;
                mol.Mole_in_brace[index1] = mole_in_brace1;
                mol.Mole_in_brace[index2] = mole_in_brace2;

                //Console.WriteLine("INT " + mol.PE1[index1] + " " + mol.PE1[index2]); 
                mol.KE1[index1] = e_multi * gama4;
                mol.KE1[index2] = e_multi * (1 - gama4);
                if (mol.PE1[index1] < mol.MinPE[index1])
                {
                    mol.minstruct[index1] = mol.Molecule_list[index1];
                    mol.MinPE[index1] = mol.PE1[index1];
                    mol.Minhit[index1] = mol.Numhit[index1];
                }
                if (mol.PE1[index2] < mol.MinPE[index2])
                {
                    mol.minstruct[index2] = mol.Molecule_list[index2];
                    mol.MinPE[index2] = mol.PE1[index2];
                    mol.Minhit[index2] = mol.Numhit[index2];
                }
                Console.WriteLine("multiple_point");
            }
        }
        //end multiple point

        public void Uniformoperator(int [] w1, int [] w2, int index1, int index2)
        {
            temp = new List<string>();
            int[] nw = uniform.uniform_operator(w1, w2);
            double pe_new = calculatePE(nw);
            string mol_in_brace = temp[0];
           // Console.WriteLine(mol_in_brace.ToString());
           // Console.WriteLine("SYN "+pe_new);

            double ke_new;
            if((mol.PE1[index1]+mol.PE1[index2] + mol.KE1[index1]+mol.KE1[index2])>=pe_new)
            {
                mol.Molecule_list.RemoveAt(index1);
                mol.PE1.RemoveAt(index1);
                mol.KE1.RemoveAt(index1);
                mol.Numhit.RemoveAt(index1);
                mol.Minhit.RemoveAt(index1);
                mol.minstruct.RemoveAt(index1);
                mol.MinPE.RemoveAt(index1);

                mol.Molecule_list.RemoveAt(index2);
                mol.PE1.RemoveAt(index2);
                mol.KE1.RemoveAt(index2);
                mol.Numhit.RemoveAt(index2);
                mol.Minhit.RemoveAt(index2);
                mol.minstruct.RemoveAt(index2);
                mol.MinPE.RemoveAt(index2);

                mol.Molecule_list.Add(nw);
                mol.PE1.Add(pe_new);
                mol.Mole_in_brace.Add(mol_in_brace);
                mol.KE1.Add((mol.PE1[index1] + mol.PE1[index2] + mol.KE1[index1] + mol.KE1[index2]) - pe_new);
                mol.Numhit.Add(0);
                mol.Minhit.Add(0);
                mol.minstruct.Add(nw);
                mol.MinPE.Add(pe_new);
                Console.WriteLine("uniform");
            }
            else
            {
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
                mol.Numhit[index1] = mol.Numhit[index1] + 1;
            }
        }
         
        
        public void cro (int popsize, double KELossRate, double MoleColl, double buffer, double initialKE, int alpha, int beta, int iteration, MoleCule_FOA mol, string file_input, string input_location_for_alignment, string output_location )
        {
            Random rand = new Random();
            align = System.IO.File.ReadAllText(input_location_for_alignment + file_input + ".txt");
            //   mol.molecule(sequence, popsize, initialKE);
            double b = 0;
            int i = 0;
            int[] w;
            int[] w1;
            int[] w2;
            int index, index1, index2;
            double minimum_energ = 1000;
            int tt=0;
            for (int j = 0; j < mol.PE1.Count; j++)
            {
                //System.IO.File.AppendAllText("o7.txt", (mol.PE1[j] + "\n "));
                if (mol.PE1[j] < minimum_energ)
                {
                    minimum_energ = mol.PE1[j];
                    tt = j;
                }
            }
           // System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + " before "+ tt.ToString() +"\n");

            
            int on, dec, sing, multi, uni, exe;
            on = 0; dec = 0; sing = 0; multi = 0; uni = 0; exe = 0;

            for (i=0; i<iteration; i++)
            {
                Console.WriteLine("Iteration         " + i);
                b = rand.NextDouble();
                if (b>MoleColl)
                {

                    index1 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index1);
                    for (int ii = 0; ii < 10000; ii++)
                    {
                        for (int jj = 0; jj < 10000; jj++)
                        {

                        }

                    }
                    index2 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index2);

                    if ((mol.Numhit[index1] - mol.Minhit[index2]) > alpha)
                    {
                        exe++;

                        //Exeoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }
                    /*index = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index);
                    /*if ((mol.Numhit[index]-mol.Minhit[index])>alpha)
                    {
                        dec++;
                       
                        Decomposition(mol.Molecule_list[index], index);

                    }
                    else
                    {
                        on++;
                        
                        OnwallIneffectiveCollision(mol.Molecule_list[index], index);
                    }*/
                }
                else
                {
                    index1 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index1);
                    for (int ii = 0; ii < 10000; ii++ )
                    {
                        for (int jj=0; jj<10000; jj++)
                        {
                            
                        }

                    }
                    index2 = rand.Next(0, mol.PE1.Count);
                    Console.WriteLine(index2);
                    if ((mol.KE1[index1] + mol.KE1[index2]) > beta)
                    {
                        multi++;
                        Multiplepointoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }

                    if ((mol.KE1[index1]+mol.KE1[index2])<beta)
                    {
                        uni++;

                        Uniformoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }

                    else
                    {
                        sing++;

                        Singlepointoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    }
                }
            }
            //minimum energy findout;
            minimum_energ = 1000;
            mol.PE1 = mol.PE1;

            for (int j=0; j<mol.PE1.Count; j++)
            {
                
                if (mol.PE1[j]<minimum_energ)
                {
                    minimum_energ = mol.PE1[j];
                    minimum_energy_index = j;
                }
            }

            //the structure of minimum energy;       
             System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + "   "+minimum_energy_index+" \n");

            string final = null;

            final = mol.Mole_in_brace[minimum_energy_index];
            //counting base pairs with regarding the given sequence.
            
            
            //Console.WriteLine(align);
            Console.WriteLine(final);
            true_basepair = 0;
            false_negative_basepair = 0;
            false_positive_basepair = 0;
            for (int i1 = 0; i1 < sequence.Length; i1++ )
            {
                if (align[i1] == final[i1] && align[i1] == '(')
                {
                    true_basepair++;
                }
                if (align[i1] == '(' && final[i1] != '(')
                {
                    false_negative_basepair++;
                }
                if (align[i1]!='(' && final[i1] =='(')
                {
                    false_positive_basepair++;
                }
            }

            sensitivity =( true_basepair/ (true_basepair + false_negative_basepair))*100.0;
            Console.WriteLine(sensitivity);
            specificity =( true_basepair / (true_basepair + false_positive_basepair))*100.0;
            Console.WriteLine(specificity);
            double a, c;
            a = sensitivity * specificity * 2;
            c = sensitivity + specificity;
            f_measure = a / c;
            //f_measure =( (2 * specificity * specificity) / (specificity + sensitivity));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (align + " \n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (final + " \n"));

            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("TP = " + true_basepair + " FP = " + false_positive_basepair + "  FN = " + false_negative_basepair + "\n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("Sensitivity = " + sensitivity + " Specificity = " + specificity + "  F-measure = " + f_measure + "\n"));           
        }

        public double calculatePE(int[] w)
        {
           
            int size = sequence.Count();
            int sequence_length = sequence.Length;

          
            info_table1 = mol.Info_table;

            int[] flag = new int[sequence_length];
            for (int i = 0; i < sequence_length; i++)
            {
                flag[i] = 0;
            }
            int[] number_sequence = new int[w.Length];
            number_sequence = w;

            char[] moll = new char[sequence_length];
            for (int i = 0; i < sequence_length; i++)
            {
                moll[i] = '.';
            }
            info_for_energy = new List<entry_table>();
            int c_for_a = 0;

            moll = rearange(info_table1,sequence, align, number_sequence, moll, mol.Condition_for_align);

            //sort info for energy 
            for (int i = 0; i < info_for_energy.Count; i++)
            {
                for (int j = i + 1; j < info_for_energy.Count; j++)
                {
                    if (info_for_energy[j].start < info_for_energy[i].start)
                    {
                        info = info_for_energy[i];
                        info_for_energy[i] = info_for_energy[j];
                        info_for_energy[j] = info;
                    }
                }
            }
            int found_multiple = 0;
            int no_of_stem = 0;
            double ener = 0;
            double to_ener = 0;
            for (int i=0; i<info_for_energy.Count-1; i++)
            {
                if (info_for_energy[i].start+1 == info_for_energy[i+1].start)
                {
                    found_multiple = 1;
                    if (no_of_stem==0 && ((sequence[Convert.ToInt16(info_for_energy[i].start)] == 'a' && sequence[Convert.ToInt16(info_for_energy[i].end)]=='u')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'a')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'g' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'u')|| (sequence[Convert.ToInt16(info_for_energy[i].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i].end)] == 'g')))
                    {
                        ener += 0.45;
                    }
                    
                    no_of_stem++;
                    ener+= calculate_energy(sequence[Convert.ToInt32(info_for_energy[i].start)], sequence[Convert.ToInt32(info_for_energy[i].end)], sequence[Convert.ToInt32(info_for_energy[i + 1].start)], sequence[Convert.ToInt32(info_for_energy[i + 1].end)]);
                    try
                    {
                        if (info_for_energy[i + 1].start + 1 == info_for_energy[i + 2].start && ((sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'a' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'a') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'g' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'u') || (sequence[Convert.ToInt16(info_for_energy[i + 1].start)] == 'u' && sequence[Convert.ToInt16(info_for_energy[i + 1].end)] == 'g')))
                        {
                            ener += 0.45;
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
                if ((info_for_energy[i].start + 1 != info_for_energy[i + 1].start) && (found_multiple == 1))
                {
                    //ener += 4.09;
                    to_ener += ener;
                    ener = 0;
                    no_of_stem = 0;
                    found_multiple = 0;
                }
            }
            to_ener += 4.09; 

            string mo = null;
            for (int i = 0; i < sequence_length; i++)
            {
                mo += moll[i];
            }
            temp.Add(mo);
            //Console.WriteLine(total_energy+" method");
            return to_ener;
        }

        public char[] rearange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] mol, int condition_for_align)
        {
            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }
            info_for_energy = new List<entry_table>();
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {
                        if (flag[i1] == 0 && flag[j1] == 0)
                        {
                            flag[i1] = 1;
                            mol[i1] = '(';
                            flag[j1] = 1;
                            mol[j1] = ')';
                            info.start = i1;
                            info.end = j1;
                            info_for_energy.Add(info);
                        }
                    }

                }
            }
            catch (Exception )
            {               
            }
            return mol;
        }

        private double calculate_energy(char p1, char p2, char p3, char p4)
        {
            double ene = 0;
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.10;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.55;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.36;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.08;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.24;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.33;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.0;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.27;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'a' && p4 == 'u'))
            {
                ene = -2.35;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 's' && p3 == 'u' && p4 == 's'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'a' && p4 == 'u') || (p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.11;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.51;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -.5;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'g'))
            {
                ene = +1.29;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.41;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.53;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = +.3;
                return ene;
            }
            if ((p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'c'))
            {
                ene = -2.36;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'c' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.42;
                return ene;
            }
         
            if ((p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.26;
                return ene;
            }
            return ene;
        }
        public char[] rearrange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] moll, int condition_for_align)
        {
            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }
            info_for_energy = new List<entry_table>();
            int c_for_a = 0;
            //adding parenthesis
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {
                        if (flag[i1] == 0 && flag[j1] == 0)
                        {
                            if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && c_for_a > mol.Condition_for_align)
                            {
                                flag[i1] = 1;
                                flag[j1] = 1;
                                continue;
                            }
                            else if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && mol.Condition_for_align > c_for_a)
                            {
                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);
                                c_for_a++;
                            }
                            else if ((Align[Convert.ToInt16(i1)] == '(' && Align[Convert.ToInt16(j1)] == ')'))
                            {

                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);
                            } 
                        }
                    }

                }
            }
            catch (Exception)
            {
            }
            return moll;
        }
    }
}
