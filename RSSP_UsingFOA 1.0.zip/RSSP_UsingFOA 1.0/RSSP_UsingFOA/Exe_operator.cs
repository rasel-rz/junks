﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class Exe_operator
    {
        public Population pop = new Population();
        Repair rep = new Repair();
        private int[] m_new;

        public int[] M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }

        

        public int[] exe_operator(int[] m1, int[] m2)
        {
            Random rand = new Random();
            m_new = new int[m1.Length];

            List<int> result = new List<int>();
            List<int> m1_list = m1.OfType<int>().ToList();
            Random random = new Random();
            for (int i = 0; result.Count < 20; i++)
            {
                int temp = random.Next(0, m1.Length);
                if (!result.Contains(temp))
                {
                    if(i % 2 == 0)
                    {
                        result.Add(m1[temp]);
                        m1_list.RemoveAt(temp);
                    }
                    else
                    {
                        result.Add(m2[temp]);
                    }
                }
            }
            while(result.Count != m1.Length)
            {
                int picked = random.Next(0, m1_list.Count);
                result.Add(m1_list[picked]);
                m1_list.RemoveAt(picked);
            }

            m_new = rep.repair_operator(result.ToArray());
            return m_new;


        }
    }
}
