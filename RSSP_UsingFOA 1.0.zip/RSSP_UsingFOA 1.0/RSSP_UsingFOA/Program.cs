﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using LisT;
using RSSP_UsingFOA;

namespace RSSP_UsingCRO
{
    class Program
    {
        
        static void Main(string[] args)
        {
           // Stopwatch stopwatch = Stopwatch.StartNew();
            
            Random rand = new Random();
            int popsize = 200;
            int iteration =50;

            double KELossRate= .8;
            double MoleColl= .3;
            double InitialKE= 2;
            int alpha = 1;
            int beta =  8;
            double buffer =0;

            int condition_g =5;
            int condition_coun = 3;

            RSSP_UsingFOA.Population pop = new Population();
            
            
            string seq = null;
            pop.Input_location = @"G:\RSSP using FOA\RSSP_UsingFOA 2.0\RSSP_UsingFOA 1.0\RSSP_UsingFOA\bin\Debug\Final Sequence\";
            string input_for_alignment = @"G:\RSSP using FOA\RSSP_UsingFOA 2.0\RSSP_UsingFOA 1.0\RSSP_UsingFOA\bin\Debug\Final Sequence\Alignment\";
            string output_location = @"G:\RSSP using FOA\RSSP_UsingFOA 2.0\RSSP_UsingFOA 1.0\RSSP_UsingFOA\bin\Debug\Final Sequence\output\";

            Console.WriteLine("Input the file name:");
            //sample: 1 G.stearothermophilus (AJ251080)
            string file_input = Console.ReadLine();
            for (int g=0; g<5; g++)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                pop.Align = System.IO.File.ReadAllText(input_for_alignment + file_input + ".txt");
                seq = System.IO.File.ReadAllText(pop.Input_location + file_input + ".txt");
                seq = seq.ToLower();


                //System.IO.File.AppendAllText(output_location + file_input + ".txt", ("\nkelossrate " + KELossRate + " \nmolecoll " + MoleColl + "\ninitialke " + InitialKE + "\nbuffer " + buffer + "\ncondition gu " + condition_g + "\ncondition count " + condition_coun + "\n"));
                System.IO.File.AppendAllText(output_location + file_input + ".txt", ("\nFEnergy " + " Index "+ "\n" ));

                MoleCule_FOA mole = new MoleCule_FOA();
                mole.Condition_gu = condition_g;
                mole.Condtion_count = condition_coun;
                list lis = new list();
                mole.Condition_for_align = lis.count(seq.Length);
                mole.molecule(seq, popsize, InitialKE, pop.Align);

                for (int i = 0; i < mole.PE1.Count; i++)
                {
                    //System.IO.File.AppendAllText(output_location+file_input+ "_PE_Before_"+".txt", (mole.PE1[i] + "\n "));
                }
                FOA_RSSP cro;
                cro = new FOA_RSSP(popsize, KELossRate, MoleColl, InitialKE, alpha, beta, buffer, seq, mole);

                cro.cro(popsize, KELossRate, MoleColl, buffer, InitialKE, alpha, beta, iteration, mole, file_input, input_for_alignment, output_location);
                //cro.cro(80, .6, .2, .1, 0, 5, 40, 20,mole);
                for (int i = 0; i < mole.PE1.Count; i++)
                {
                    //System.IO.File.AppendAllText(output_location+file_input+"_PE_lAfter_"+".txt", (mole.PE1[i] + "\n "));
                }
              //Console.ReadLine();
                System.Threading.Thread.Sleep(500);
                stopwatch.Stop();
                double t = (double.Parse(stopwatch.ElapsedMilliseconds.ToString())) / 1000;
                Console.WriteLine(t.ToString());
                //System.IO.File.AppendAllText(output_location + file_input + ".txt", ("alpha " + alpha + " beta " + beta + " \n"));

                System.IO.File.AppendAllText(output_location + file_input + ".txt", ("Time elapsed :  " + t.ToString() + " \n\n"));

            }

        }
    }
}
