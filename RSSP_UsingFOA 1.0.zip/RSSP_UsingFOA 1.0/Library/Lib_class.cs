﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Library
{
    struct entry_table
    {
        public Int64 start;
        public Int64 end;
        public Int64 length;
    };
    // This project can output the Class library as a NuGet Package.
    // To enable this option, right-click on the project and select the Properties menu item. In the Build tab select "Produce outputs on build".
    public class Lib_class
    {
        List<entry_table> info_table1 = new List<entry_table>();
        List<entry_table> info_for_energy = new List<entry_table>();

        

        entry_table info = new entry_table();
        private string align = "";



        private string sequence;
        private Int64 sequence_length;
        int[] number_sequence ;
        char[] mol ;

      
        public Lib_class()
        {
        }

        public char[] seq (string align, string sequence, int[] number_sequence, List<entry_table> info_table1)
        {
            char[] mol = new char[sequence.Length];

            
            for (int i = 0; i < sequence_length; i++)
            {
                mol[i] = '.';
            }



            return mol;
        }
    }
}
