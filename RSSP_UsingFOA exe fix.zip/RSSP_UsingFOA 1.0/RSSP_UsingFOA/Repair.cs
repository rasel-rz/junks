﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class Repair
    {
        private int[] m_new = new int[10000];

        public int[] New
        {
            get
            {
                return m_new;
            }

            set
            {
                m_new = value;
            }
        }
        public int [] repair_operator (int [] m)
        {
            //Console.Write("hi");
            int[] flag = new int[m.Length];
            List<int> m_list=new List<int>();
           // Console.WriteLine("   before " + m.Length);
            for (int i=0; i<m.Length; i++)
            {
                flag[i] = 0;
                
                m_list.Add(m[i]);
                
                if (m_list[i] < 0 || m_list[i]>=m.Length)
                {
                    m_list[i] = 1;
                }
            }
            for (int i=0; i<m_list.Count;i++)
            { 
                
                if (flag[m_list[i]]==0)
                {
                    flag[m_list[i]] = 1;
                }
                else if(flag[m_list[i]]!=0)
                {
                    m_list.RemoveAt(i);
                    i = i - 1;
                }
            }
            m_new = new int[m_list.Count];
            for (int j=0; j<m_list.Count; j++)
            {
                m_new[j] = m_list[j];
            }
           // Console.WriteLine("After  "+m_new.Length);
            return m_new;
        }
    }
}
