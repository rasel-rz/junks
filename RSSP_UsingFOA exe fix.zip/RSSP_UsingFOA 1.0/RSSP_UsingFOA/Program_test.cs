﻿using RSSP_UsingFOA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingCRO
{
    class Program
    {
        static void Main(string[] args)
        {
            Exe_operator exe = new Exe_operator();
            int[] m1 = { 1, 3, 4, 5, 6, 7, 8, 2 };
            int[] m2 = { 8, 6, 7, 3, 5, 4, 2, 1 };
            var result = exe.exe_operator(m1, m2);
            Console.WriteLine(string.Join(", ", result));
        }
    }
}
