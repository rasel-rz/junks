﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{

    class FOA_RSSP
    {


        List<entry_table> info_table = new List<entry_table>();
        List<entry_table> info_table1 = new List<entry_table>();
        List<entry_table> info_for_energy = new List<entry_table>();
        List<string> temp = new List<string>();
        entry_table info = new entry_table();
        private string align = "";



        private Int64[,] zero_one = new Int64[1000, 1000];
        private Int64[,] zero_one_2 = new Int64[1000, 1000];

        double sensitivity;
        double specificity;
        double f_measure;
        double true_basepair;
        double false_negative_basepair;
        double false_positive_basepair;
        double INF;
        int popsize;


        public string sequence = null;
        public int minimum_energy_index;
        public FOA_RSSP(int popsize, double MoleColl, string sequence, MoleCule_FOA mol)
        {
            this.mol = mol;
            this.popsize = popsize;
            this.sequence = sequence;


        }

        Single_point_operator single_point = new Single_point_operator();
        Multiple_point_operator multiple_point = new Multiple_point_operator();
        Uniform_operator uniform = new Uniform_operator();
        Exe_operator exe = new Exe_operator();
        public MoleCule_FOA mol = new MoleCule_FOA();



        public string Align
        {
            get
            {
                return align;
            }

            set
            {
                align = value;
            }
        }

        public void FOA_try(int popsize, double moleColl, int iteration, MoleCule_FOA mole, string file_input, string input_location_for_alignment, string output_location)
        {

            //Random random = new Random();
            Random rand = new Random();
            align = System.IO.File.ReadAllText(input_location_for_alignment + file_input + ".txt");
            int X = 1;
            int Y = 1;
            int X_i = X + rand.Next(0, 50);
            int Y_i = Y + rand.Next(0, 50);
            double Distance = Math.Sqrt((X_i * X_i) + (Y_i * Y_i));
            float Smell = (float)(1 / Distance);

           
            int index1, index2;
            double minimum_energ = 1000;
            int sing, multi, uni, exe;
            sing = 0; multi = 0; uni = 0; exe = 0;

            int i = 0;

            for (i = 0; i < iteration; i++)
            {
                index1 = rand.Next(0, mol.PE1.Count);
                Console.WriteLine(index1);
                index2 = rand.Next(0, mol.PE1.Count);
                Console.WriteLine(index2);

                if (Smell < 0.2)
                {

                    sing++;

                    Singlepointoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    // Do your Single Point Operation Here on the @param sequence'
                    float temp = rand.Next(0, 100) / 100;
                    if (temp < 0.6)
                    {
                        uni++;

                        Uniformoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                        // DO your Uniform Operation Here on the OUTPUT of Single Point Operator
                    }
                    else
                    {
                        exe++;

                        Exeoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                        // DO your EXE Operation Here on the OUTPUT of Single Point Operator
                    }
                }
                else
                {

                    multi++;
                    Multiplepointoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                    // Do your MultiPoint Operation Here on the @param 'sequence'
                    float vision = rand.Next(0, 100) / 100;
                    if (vision < 0.7)
                    {
                        exe++;

                        Exeoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                        // DO your EXE Operation Here on the OUTPUT of Single Point Operator
                    }
                    else
                    {
                        uni++;

                        Uniformoperator(mol.Molecule_list[index1], mol.Molecule_list[index2], index1, index2);
                        // DO your Uniform Operation Here on the OUTPUT of Single Point Operator
                    }
                }
            }
            minimum_energ = 1000;
            mol.PE1 = mol.PE1;

            for (int j = 0; j < mol.PE1.Count; j++)
            {

                if (mol.PE1[j] < minimum_energ)
                {
                    minimum_energ = mol.PE1[j];
                    minimum_energy_index = j;
                }
            }

            //the structure of minimum energy;       
            System.IO.File.AppendAllText(output_location + file_input + ".txt", minimum_energ.ToString() + "   " + minimum_energy_index + " \n");

            string final = null;

            final = mol.Mole_in_brace[minimum_energy_index];
            //counting base pairs with regarding the given sequence.


            //Console.WriteLine(align);
            Console.WriteLine(final);
            true_basepair = 0;
            false_negative_basepair = 0;
            false_positive_basepair = 0;
            for (int i1 = 0; i1 < sequence.Length; i1++)
            {
                if (align[i1] == final[i1] && align[i1] == '(')
                {
                    true_basepair++;
                }
                if (align[i1] == '(' && final[i1] != '(')
                {
                    false_negative_basepair++;
                }
                if (align[i1] != '(' && final[i1] == '(')
                {
                    false_positive_basepair++;
                }
            }

            sensitivity = (true_basepair / (true_basepair + false_negative_basepair)) * 100.0;
            Console.WriteLine(sensitivity);
            specificity = (true_basepair / (true_basepair + false_positive_basepair)) * 100.0;
            Console.WriteLine(specificity);
            double b;
            b = sensitivity * specificity;
            INF = Math.Sqrt(b);
            Console.WriteLine(INF);
            double a, c;
            a = sensitivity * specificity * 2;
            c = sensitivity + specificity;
            f_measure = a / c;
            //f_measure =( (2 * specificity * specificity) / (specificity + sensitivity));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (align + " \n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", (final + " \n"));

            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("TP = " + true_basepair + " FP = " + false_positive_basepair + "  FN = " + false_negative_basepair + "\n"));
            System.IO.File.AppendAllText(output_location + file_input + ".txt", ("Sensitivity = " + sensitivity + " Specificity = " + specificity + "  F-measure = " + f_measure + "   INF=  "+ INF +"\n"));
        }

        

       
        public void Exeoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            int[] nw = exe.exe_operator(w1, w2);
            //double pe_new = calculatePE(nw);
            string mol_in_brace = temp[0];
            
        }


        public void Singlepointoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
            nw = single_point.single_point_operator(w1, w2);
            int[] nw1 = nw[0];
            int[] nw2 = nw[1];
            Random rand = new Random();
           
            Console.WriteLine("single_point");
        }
        //multiple point  1
        public void Multiplepointoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            List<int[]> nw = new List<int[]>();
            nw = multiple_point.multiple_point_operator(w1, w2);
            int[] nw1 = nw[0];
            int[] nw2 = nw[1];
            Random rand = new Random();
           
            Console.WriteLine("multiple_point");
        }
        //end multiple point

        public void Uniformoperator(int[] w1, int[] w2, int index1, int index2)
        {
            temp = new List<string>();
            int[] nw = uniform.uniform_operator(w1, w2);
           
            Console.WriteLine("uniform");
        }


       
        public char[] rearange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] mol, int condition_for_align)
        {
            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }
            info_for_energy = new List<entry_table>();
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {
                        if (flag[i1] == 0 && flag[j1] == 0)
                        {
                            flag[i1] = 1;
                            mol[i1] = '(';
                            flag[j1] = 1;
                            mol[j1] = ')';
                            info.start = i1;
                            info.end = j1;
                            info_for_energy.Add(info);
                        }
                    }

                }
            }
            catch (Exception)
            {
            }
            return mol;
        }

        private double calculate_energy(char p1, char p2, char p3, char p4)
        {
            double ene = 0;
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.10;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -.55;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'a'))
            {
                ene = -1.36;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.08;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'a'))
            {
                ene = -2.24;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.33;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.0;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'u' && p4 == 'g') || (p1 == 'g' && p2 == 'u' && p3 == 'a' && p4 == 'u'))
            {
                ene = -1.27;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'a' && p4 == 'u'))
            {
                ene = -2.35;
                return ene;
            }
            if ((p1 == 'a' && p2 == 'u' && p3 == 'a' && p4 == 'u') || (p1 == 'u' && p2 == 's' && p3 == 'u' && p4 == 's'))
            {
                ene = -.93;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'a' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'a' && p4 == 'u') || (p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.11;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'u' && p4 == 'g'))
            {
                ene = -2.51;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'g' && p4 == 'u') || (p1 == 'u' && p2 == 'g' && p3 == 'u' && p4 == 'g'))
            {
                ene = -.5;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'u' && p3 == 'u' && p4 == 'g'))
            {
                ene = +1.29;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.41;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'c' && p4 == 'g') || (p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'u'))
            {
                ene = -1.53;
                return ene;
            }
            if ((p1 == 'u' && p2 == 'g' && p3 == 'g' && p4 == 'u'))
            {
                ene = +.3;
                return ene;
            }
            if ((p1 == 'c' && p2 == 'g' && p3 == 'g' && p4 == 'c'))
            {
                ene = -2.36;
                return ene;
            }
            if ((p1 == 'g' && p2 == 'c' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.42;
                return ene;
            }

            if ((p1 == 'g' && p2 == 'c' && p3 == 'g' && p4 == 'c') || (p1 == 'c' && p2 == 'g' && p3 == 'c' && p4 == 'g'))
            {
                ene = -3.26;
                return ene;
            }
            return ene;
        }
        public char[] rearrange(List<entry_table> info_table1, string sequence, string align, int[] number_sequence, char[] moll, int condition_for_align)
        {
            int[] flag = new int[sequence.Length];
            for (int i = 0; i < sequence.Length; i++)
            {
                flag[i] = 0;
            }
            info_for_energy = new List<entry_table>();
            int c_for_a = 0;
            //adding parenthesis
            try
            {
                for (int i = 0; i < number_sequence.Length; i++)
                {
                    for (Int64 i1 = info_table1[number_sequence[i]].start, j1 = info_table1[number_sequence[i]].end; i1 < (info_table1[number_sequence[i]].length + info_table1[number_sequence[i]].start); i1++, j1--)
                    {
                        if (flag[i1] == 0 && flag[j1] == 0)
                        {
                            if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && c_for_a > mol.Condition_for_align)
                            {
                                flag[i1] = 1;
                                flag[j1] = 1;
                                continue;
                            }
                            else if ((Align[Convert.ToInt16(i1)] == '.' || Align[Convert.ToInt16(j1)] == '.') && mol.Condition_for_align > c_for_a)
                            {
                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);
                                c_for_a++;
                            }
                            else if ((Align[Convert.ToInt16(i1)] == '(' && Align[Convert.ToInt16(j1)] == ')'))
                            {

                                flag[i1] = 1;
                                moll[i1] = '(';
                                flag[j1] = 1;
                                moll[j1] = ')';
                                info.start = i1;
                                info.end = j1;
                                info_for_energy.Add(info);
                            }
                        }
                    }

                }
            }
            catch (Exception)
            {
            }
            return moll;
        }
    }
}
