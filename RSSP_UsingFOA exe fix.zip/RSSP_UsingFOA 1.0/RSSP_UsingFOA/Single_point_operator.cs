﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class Single_point_operator
    {
        Population pop = new Population();
        Repair rep = new Repair();
        List<int[]> m_new = new List<int[]>();

        private List<int[]> M_new
        {
            get { return m_new; }
            set { m_new = value; }
        }

        public List<int[]> single_point_operator(int[] m1, int[] m2)
        {
            int x1, x2;
            int[] m11 = new int[m1.Length];
            int[] m22 = new int[m2.Length];
            Random rand = new Random();
            x1 = rand.Next(0,m1.Length);
            for (int i1 = 0; i1 < 4000; i1++)
                {
                    for (int i2 = 0; i2 < 2000; i2++)
                    {

                    }
                }
            x2 = rand.Next(0,m1.Length);
            /*for (int i = 0; i < m1.Length; i++ )
            {
                if (i<x1 || i>x2)
                {
                    try
                    {
                        m11[i] = m1[i];
                        m22[i] = m2[i];
                    }
                    catch (Exception)
                    {
                        
                        
                    }

                }
                else if (i>=x1 && x2>=i)
                {
                    m11[i] = m2[i];
                    m22[i] = m1[i];
                }
            }*/



            for (int i = 0; i < x1; i++)
            {
                try
                {
                    m11[i] = m1[i];
                }
                catch (Exception)
                {


                }
            }
            for (int i = x1; i < m2.Length; i++)
            {
                try
                {
                    m11[i] = m2[i];
                }
                catch (Exception)
                {


                }
            }

            for (int i = 0; i < x1; i++)
            {
                try
                {
                    m22[i] = m2[i];
                }
                catch (Exception)
                {


                }
            }
            for (int i = x1; i < m1.Length; i++)
            {
                try
                {
                    m22[i] = m1[i];
                }
                catch (Exception)
                {


                }
            }

            m11 = rep.repair_operator(m11);
            m22 = rep.repair_operator(m22);
            m_new.Add(m11);
            m_new.Add(m22);

            return m_new;
        }
    }
}
