﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSSP_UsingFOA
{
    class MoleCule_FOA
    {
        public Population pop = new Population();
        private List<int[]> molecule_list;
        private List<double> PE = new List<double>();
        private List<double> KE = new List<double>();
        private List<int> numhit = new List<int>();
        private List<double> minPE = new List<double>();
        private List<int> minhit = new List<int>();
        public List<int[]> minstruct = new List<int[]>();
        private List<string> mole_in_brace = new List<string>();
        private string seqence;
        public double initialke = 1;

        private int condition_gu = 0;
        private int condtion_count = 0;
        private int condition_for_align = 0;

        List<entry_table> info_table = new List<entry_table>();

        public string Seqence
        {
            get { return seqence; }
            set { seqence = value; }
        }
        
        public List<int> Numhit
        {
            get { return numhit; }
            set { numhit = value; }
        }
       
        public List<double> MinPE
        {
            get { return minPE; }
            set { minPE = value; }
        }
        
        public List<int> Minhit
        {
            get { return minhit; }
            set { minhit = value; }
        }
        public List<double> KE1
        {
            get { return KE; }
            set { KE = value; }
        }
        public List<double> PE1
        {
            get { return PE; }
            set { PE = value; }
        }
        public List<int[]> Molecule_list
        {
            get { return molecule_list; }
            set { molecule_list = value; }
        }
      
        
        
        private List<int[]> Minstruct
        {
            get { return minstruct; }
            set { minstruct = value; }
        }

        public int Condition_gu
        {
            get
            {
                return condition_gu;
            }

            set
            {
                condition_gu = value;
            }
        }

        public int Condtion_count
        {
            get
            {
                return condtion_count;
            }

            set
            {
                condtion_count = value;
            }
        }

        internal List<entry_table> Info_table
        {
            get
            {
                return info_table;
            }

            set
            {
                info_table = value;
            }
        }

        public List<string> Mole_in_brace
        {
            get
            {
                return mole_in_brace;
            }

            set
            {
                mole_in_brace = value;
            }
        }

        public int Condition_for_align
        {
            get
            {
                return condition_for_align;
            }

            set
            {
                condition_for_align = value;
            }
        }

        public void molecule(string sequence, int no_of_population, double initialke, string align)
        {
            pop.checkerboard(sequence, no_of_population, Condition_gu, Condtion_count,align, Condition_for_align);
            info_table = pop.Info_table1;
            
            molecule_list = pop.molecule_table;
            Mole_in_brace = pop.molecule;
            PE = pop.molecule_energy; 
            for (int i=0; i<molecule_list.Count; i++)
            {
                KE.Add(initialke);
                numhit.Add(0);
                minstruct.Add(molecule_list[i]);
                minPE.Add(PE[i]);
                minhit.Add(0);
            }

        }
        
    }
}
